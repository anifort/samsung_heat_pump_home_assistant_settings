#!/bin/bash
set -e

/usr/bin/python3 oeha_server.py &