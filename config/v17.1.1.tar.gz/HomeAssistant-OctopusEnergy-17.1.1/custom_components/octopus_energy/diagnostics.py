"""Diagnostics support."""
import copy
from datetime import datetime, timedelta
import logging
from typing import Callable

from .utils.attributes import dict_to_typed_dict
from homeassistant.components.diagnostics import async_redact_data
from homeassistant.helpers import entity_registry as er
from homeassistant.util.dt import (now)

from .const import (
  CONFIG_ACCOUNT_ID,
  CONFIG_COST_TRACKER_MPAN,
  CONFIG_COST_TRACKER_TARGET_ENTITY_ID,
  CONFIG_MAIN_API_KEY,
  DATA_ACCOUNT,
  DOMAIN,

  DATA_CLIENT
)
from .api_client import OctopusEnergyApiClient, TimeoutException
from .heat_pump import get_mock_heat_pump_id, mock_heat_pump_status_and_configuration
from .utils.debug_overrides import AccountDebugOverride, async_get_account_debug_override

_LOGGER = logging.getLogger(__name__)

async def async_get_device_consumption_data(client: OctopusEnergyApiClient, device_id: str):
  current: datetime = now()
  period_from = current - timedelta(minutes=120)
  period_to = current
  try:
    consumption_data = await client.async_get_smart_meter_consumption(
      device_id,
      period_from,
      period_to)
  
    if consumption_data is not None and len(consumption_data) > 0:
      return consumption_data[-1]
    
    return "Not available"
  
  except Exception as e:
    return f"Failed to retrieve - {e}"

async def async_get_diagnostics(client: OctopusEnergyApiClient, account_id: str, existing_account_info: dict, account_debug_override: AccountDebugOverride | None, get_entity_info: Callable[[dict], dict]):
  _LOGGER.info('Retrieving account details for diagnostics...')

  if existing_account_info is None:
    account_info = await client.async_get_account(account_id)
  else:
    account_info = copy.deepcopy(existing_account_info)

  redacted_mappings = {}
  redacted_mapping_count = 1

  if account_info is not None:
    redacted_mappings[account_info["id"]] = "A"

  points_length = account_info is not None and len(account_info["electricity_meter_points"])
  if account_info is not None and points_length > 0:
    for point_index in range(points_length):
      meters_length = len(account_info["electricity_meter_points"][point_index]["meters"])
      for meter_index in range(meters_length):

        try:
          consumptions = await client.async_get_electricity_consumption(account_info["electricity_meter_points"][point_index]["mpan"], account_info["electricity_meter_points"][point_index]["meters"][meter_index]["serial_number"], page_size=1)
          account_info["electricity_meter_points"][point_index]["meters"][meter_index]["latest_consumption"] = consumptions[-1]["end"] if consumptions is not None and len(consumptions) > 0 else "Not available"
        except TimeoutException:
          account_info["electricity_meter_points"][point_index]["meters"][meter_index]["latest_consumption"] = "time out"

        device_id  = account_info["electricity_meter_points"][point_index]["meters"][meter_index]["device_id"]
        if device_id is not None and device_id != "":
          account_info["electricity_meter_points"][point_index]["meters"][meter_index]["latest_device_consumption"] = await async_get_device_consumption_data(client, device_id)
        
        redacted_mappings[f"{account_info["electricity_meter_points"][point_index]["meters"][meter_index]["serial_number"]}"] = redacted_mapping_count
        account_info["electricity_meter_points"][point_index]["meters"][meter_index]["serial_number"] = redacted_mapping_count
        redacted_mapping_count += 1
        
        account_info["electricity_meter_points"][point_index]["meters"][meter_index] = async_redact_data(account_info["electricity_meter_points"][point_index]["meters"][meter_index], { "device_id" })
      
      redacted_mappings[f"{account_info["electricity_meter_points"][point_index]["mpan"]}"] = redacted_mapping_count
      account_info["electricity_meter_points"][point_index]["mpan"] = redacted_mapping_count
      redacted_mapping_count += 1

  points_length = account_info is not None and len(account_info["gas_meter_points"])
  if account_info is not None and points_length > 0:
    for point_index in range(points_length):
      meters_length = len(account_info["gas_meter_points"][point_index]["meters"])
      for meter_index in range(meters_length):
        
        try:
          consumptions = await client.async_get_gas_consumption(account_info["gas_meter_points"][point_index]["mprn"], account_info["gas_meter_points"][point_index]["meters"][meter_index]["serial_number"], page_size=1)
          account_info["gas_meter_points"][point_index]["meters"][meter_index]["latest_consumption"] = consumptions[-1]["end"] if consumptions is not None and len(consumptions) > 0 else "Not available"
        except TimeoutException:
          account_info["gas_meter_points"][point_index]["meters"][meter_index]["latest_consumption"] = "time out"

        device_id  = account_info["gas_meter_points"][point_index]["meters"][meter_index]["device_id"]
        if device_id is not None and device_id != "":
          account_info["gas_meter_points"][point_index]["meters"][meter_index]["latest_device_consumption"] = await async_get_device_consumption_data(client, device_id)

        redacted_mappings[f"{account_info["gas_meter_points"][point_index]["meters"][meter_index]["serial_number"]}"] = redacted_mapping_count
        account_info["gas_meter_points"][point_index]["meters"][meter_index]["serial_number"] = redacted_mapping_count
        redacted_mapping_count += 1

        account_info["gas_meter_points"][point_index]["meters"][meter_index] = async_redact_data(account_info["gas_meter_points"][point_index]["meters"][meter_index], { "device_id" })

      redacted_mappings[f"{account_info["gas_meter_points"][point_index]["mprn"]}"] = redacted_mapping_count
      account_info["gas_meter_points"][point_index]["mprn"] = redacted_mapping_count
      redacted_mapping_count += 1

  intelligent_devices_dict = []
  intelligent_devices = await client.async_get_intelligent_devices(account_id)
  for idx, intelligent_device in enumerate(intelligent_devices):
    intelligent_device_dict = intelligent_device.to_dict()
    intelligent_settings = await client.async_get_intelligent_settings(account_id, intelligent_device.id)
    intelligent_device_dict["id"] = "**REDACTED**"
    intelligent_device_dict["settings"] = intelligent_settings.to_dict() if intelligent_settings is not None else None

    intelligent_devices_dict.append(intelligent_device_dict)
  
  _LOGGER.info(f'Returning diagnostic details; {len(account_info["electricity_meter_points"])} electricity meter point(s), {len(account_info["gas_meter_points"])} gas meter point(s)')

  account_info = async_redact_data(account_info, { "id" }) if account_info is not None else None

  mock_heat_pump = account_debug_override.mock_heat_pump if account_debug_override is not None else False

  heat_pumps = {}
  if mock_heat_pump:
    heat_pump_id = get_mock_heat_pump_id()
    heat_pumps[heat_pump_id] = mock_heat_pump_status_and_configuration().dict()
  elif "heat_pump_ids" in account_info:
    for heat_pump_id in account_info["heat_pump_ids"]:
      try:
        heat_pump = await client.async_get_heat_pump_configuration_and_status(account_id, heat_pump_id)
        heat_pumps[heat_pump_id] = heat_pump.dict() if heat_pump is not None else "Not found"
      except Exception as e:
        heat_pumps[heat_pump_id] = f"Failed to retrieve - {e}"

  return {
    "timestamp_captured": now(),
    "account": account_info,
    "using_cached_account_data": existing_account_info is not None,
    "entities": get_entity_info(redacted_mappings),
    "intelligent_devices": list(map(lambda x: x.to_dict(), intelligent_devices)),
    "heat_pumps": heat_pumps,
  }

ignored_attributes = ['mpan', 'mprn', 'serial_number', 'friendly_name', 'icon', 'unit_of_measurement', 'device_class', 'state_class', 'account_id']

async def async_get_device_diagnostics(hass, entry, device):
    """Return diagnostics for a device."""

    config = dict(entry.data)
    
    account_id = config[CONFIG_ACCOUNT_ID]
    account_result = hass.data[DOMAIN][account_id][DATA_ACCOUNT]
    account_info = account_result.account if account_result is not None else None
    client: OctopusEnergyApiClient = hass.data[DOMAIN][account_id][DATA_CLIENT]
    account_debug_override = await async_get_account_debug_override(hass, account_id)

    def get_entity_info(redacted_mappings):
      entity_registry = er.async_get(hass)
      entities = entity_registry.entities.items()
      states = hass.states.async_all()
      entity_info = dict()
      for item in entities:
        unique_id: str = item[1].unique_id

        if "octopus_energy" in unique_id:
          state = None
          for s in states:
            if s.entity_id == item[1].entity_id:
              state = s
              break

          for key in redacted_mappings.keys():
            unique_id = unique_id.lower().replace(key.lower(), f"{redacted_mappings[key]}")
          
          entity_info[unique_id] = {
            "state": state.state if state is not None else None,
            "attributes": dict_to_typed_dict(state.attributes, ignored_attributes) if state is not None else None,
            "last_updated": state.last_updated if state is not None else None,
            "last_changed": state.last_changed if state is not None else None
          }

      return entity_info

    diagnostics = await async_get_diagnostics(client, account_id, account_info, account_debug_override, get_entity_info)
    
    return {
      **diagnostics,
      "config_entry": async_redact_data(config, { CONFIG_ACCOUNT_ID, CONFIG_MAIN_API_KEY, CONFIG_COST_TRACKER_MPAN, CONFIG_COST_TRACKER_TARGET_ENTITY_ID }),
    }

async def async_get_config_entry_diagnostics(hass, entry):
    """Return diagnostics for a device."""

    config = dict(entry.data)
    
    account_id = config[CONFIG_ACCOUNT_ID]
    account_result = hass.data[DOMAIN][account_id][DATA_ACCOUNT]
    account_info = account_result.account if account_result is not None else None
    client: OctopusEnergyApiClient = hass.data[DOMAIN][account_id][DATA_CLIENT]
    account_debug_override = await async_get_account_debug_override(hass, account_id)

    def get_entity_info(redacted_mappings):
      entity_registry = er.async_get(hass)
      entities = entity_registry.entities.items()
      states = hass.states.async_all()
      entity_info = dict()
      for item in entities:
        unique_id: str = item[1].unique_id

        if "octopus_energy" in unique_id:
          state = None
          for s in states:
            if s.entity_id == item[1].entity_id:
              state = s
              break

          for key in redacted_mappings.keys():
            unique_id = unique_id.lower().replace(key.lower(), f"{redacted_mappings[key]}")
          
          entity_info[unique_id] = {
            "last_updated": state.last_updated if state is not None else None,
            "last_changed": state.last_changed if state is not None else None
          }

      return entity_info

    diagnostics = await async_get_diagnostics(client, account_id, account_info, account_debug_override, get_entity_info)
    
    return {
      **diagnostics,
      "config_entry": async_redact_data(config, { CONFIG_ACCOUNT_ID, CONFIG_MAIN_API_KEY, CONFIG_COST_TRACKER_MPAN, CONFIG_COST_TRACKER_TARGET_ENTITY_ID }),
    }